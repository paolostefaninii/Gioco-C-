#include<windows.h>
#include<math.h>

void suona_do();

void suona_re();

void suona_mi();

void suona_fa();

void suona_sol();

void suona_la();

void suona_si();

void test_suono();
