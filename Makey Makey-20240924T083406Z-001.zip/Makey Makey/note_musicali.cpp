#include<windows.h>
#include<math.h>
#include"note_musicali.h"

void suona_do(){
	Beep(261.63*pow(2,0/12.0),0%12==0?500:1000);
}

void suona_re(){
	Beep(261.63*pow(2,2/12.0),2%12==0?500:1000);
}

void suona_mi(){
	Beep(261.63*pow(2,4/12.0),4%12==0?500:1000);
}

void suona_fa(){
	Beep(261.63*pow(2,5/12.0),5%12==0?500:1000);
}

void suona_sol(){
	Beep(261.63*pow(2,7/12.0),7%12==0?500:1000);
}

void suona_la(){
	Beep(261.63*pow(2,9/12.0),9%12==0?500:1000);
}

void suona_si(){
	Beep(261.63*pow(2,11/12.0),11%12==0?500:1000);
}

void test_suono(){
	
    suona_do();
	suona_re();
	suona_mi();
	suona_fa();
	suona_sol();
	suona_la();
	suona_si();
	
}
