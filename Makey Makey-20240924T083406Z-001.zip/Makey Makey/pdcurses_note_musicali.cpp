#define NCURSES_MOUSE_VERSION 2
#include<curses.h>
#include"note_musicali.h"

int main(int argc, char *argv[])
{
    int ch;

	initscr();
	keypad(stdscr, TRUE);
    noecho();
	curs_set(FALSE);
    MEVENT event;
    mmask_t old;
    mousemask (ALL_MOUSE_EVENTS | REPORT_MOUSE_POSITION, &old);
    
	while(1) {

		
		ch = getch();
		if(ch == KEY_LEFT) {
            suona_do();
		}
		else if(ch == KEY_RIGHT) {
            suona_re();
		}
		else if(ch == KEY_UP) {
            suona_mi();
		}
		else if(ch == KEY_DOWN) {
            suona_fa();
		}
        else if(ch == ' '){
        	suona_sol();
		}
        else if(ch == KEY_MOUSE){
        	if(getmouse(&event) == OK) 
        	    if(event.bstate & BUTTON1_PRESSED)
        	         suona_la();
		}
		
		refresh();
	}

	getch();
	endwin();

	return 0;
}
